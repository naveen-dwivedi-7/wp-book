<?php

/**
 * Registers the `book_tag` taxonomy,
 * for use with 'book'.
 */
function book_tag_init() {
	register_taxonomy( 'book-tag', [ 'book' ], [
		'hierarchical'          => false,
		'public'                => true,
		'show_in_nav_menus'     => true,
		'show_ui'               => true,
		'show_admin_column'     => false,
		'query_var'             => true,
		'rewrite'               => true,
		'capabilities'          => [
			'manage_terms' => 'edit_posts',
			'edit_terms'   => 'edit_posts',
			'delete_terms' => 'edit_posts',
			'assign_terms' => 'edit_posts',
		],
		'labels'                => [
			'name'                       => __( 'Book Tags', 'book-tag' ),
			'singular_name'              => _x( 'Book Tag', 'taxonomy general name', 'book-tag' ),
			'search_items'               => __( 'Search Book Tags', 'book-tag' ),
			'popular_items'              => __( 'Popular Book Tags', 'book-tag' ),
			'all_items'                  => __( 'All Book Tags', 'book-tag' ),
			'parent_item'                => __( 'Parent Book Tag', 'book-tag' ),
			'parent_item_colon'          => __( 'Parent Book Tag:', 'book-tag' ),
			'edit_item'                  => __( 'Edit Book Tag', 'book-tag' ),
			'update_item'                => __( 'Update Book Tag', 'book-tag' ),
			'view_item'                  => __( 'View Book Tag', 'book-tag' ),
			'add_new_item'               => __( 'Add New Book Tag', 'book-tag' ),
			'new_item_name'              => __( 'New Book Tag', 'book-tag' ),
			'separate_items_with_commas' => __( 'Separate Book Tags with commas', 'book-tag' ),
			'add_or_remove_items'        => __( 'Add or remove Book Tags', 'book-tag' ),
			'choose_from_most_used'      => __( 'Choose from the most used Book Tags', 'book-tag' ),
			'not_found'                  => __( 'No Book Tags found.', 'book-tag' ),
			'no_terms'                   => __( 'No Book Tags', 'book-tag' ),
			'menu_name'                  => __( 'Book Tags', 'book-tag' ),
			'items_list_navigation'      => __( 'Book Tags list navigation', 'book-tag' ),
			'items_list'                 => __( 'Book Tags list', 'book-tag' ),
			'most_used'                  => _x( 'Most Used', 'book-tag', 'book-tag' ),
			'back_to_items'              => __( '&larr; Back to Book Tags', 'book-tag' ),
		],
		'show_in_rest'          => true,
		'rest_base'             => 'book-tag',
		'rest_controller_class' => 'WP_REST_Terms_Controller',
	] );

}

add_action( 'init', 'book_tag_init' );

/**
 * Sets the post updated messages for the `book_tag` taxonomy.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `book_tag` taxonomy.
 */
function book_tag_updated_messages( $messages ) {

	$messages['book-tag'] = [
		0 => '', // Unused. Messages start at index 1.
		1 => __( 'Book Tag added.', 'book-tag' ),
		2 => __( 'Book Tag deleted.', 'book-tag' ),
		3 => __( 'Book Tag updated.', 'book-tag' ),
		4 => __( 'Book Tag not added.', 'book-tag' ),
		5 => __( 'Book Tag not updated.', 'book-tag' ),
		6 => __( 'Book Tags deleted.', 'book-tag' ),
	];

	return $messages;
}

add_filter( 'term_updated_messages', 'book_tag_updated_messages' );
