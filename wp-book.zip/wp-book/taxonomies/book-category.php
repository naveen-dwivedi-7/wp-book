<?php

/**
 * Registers the `book_category` taxonomy,
 * for use with 'book'.
 */
function book_category_init() {
	register_taxonomy( 'book-category', [ 'book' ], [
		'hierarchical'          => true,
		'public'                => true,
		'show_in_nav_menus'     => true,
		'show_ui'               => true,
		'show_admin_column'     => false,
		'query_var'             => true,
		'rewrite'               => true,
		'capabilities'          => [
			'manage_terms' => 'edit_posts',
			'edit_terms'   => 'edit_posts',
			'delete_terms' => 'edit_posts',
			'assign_terms' => 'edit_posts',
		],
		'labels'                => [
			'name'                       => __( 'Book Categories', 'book-category' ),
			'singular_name'              => _x( 'Book Category', 'taxonomy general name', 'book-category' ),
			'search_items'               => __( 'Search Book Categories', 'book-category' ),
			'popular_items'              => __( 'Popular Book Categories', 'book-category' ),
			'all_items'                  => __( 'All Book Categories', 'book-category' ),
			'parent_item'                => __( 'Parent Book Category', 'book-category' ),
			'parent_item_colon'          => __( 'Parent Book Category:', 'book-category' ),
			'edit_item'                  => __( 'Edit Book Category', 'book-category' ),
			'update_item'                => __( 'Update Book Category', 'book-category' ),
			'view_item'                  => __( 'View Book Category', 'book-category' ),
			'add_new_item'               => __( 'Add New Book Category', 'book-category' ),
			'new_item_name'              => __( 'New Book Category', 'book-category' ),
			'separate_items_with_commas' => __( 'Separate Book Categories with commas', 'book-category' ),
			'add_or_remove_items'        => __( 'Add or remove Book Categories', 'book-category' ),
			'choose_from_most_used'      => __( 'Choose from the most used Book Categories', 'book-category' ),
			'not_found'                  => __( 'No Book Categories found.', 'book-category' ),
			'no_terms'                   => __( 'No Book Categories', 'book-category' ),
			'menu_name'                  => __( 'Book Categories', 'book-category' ),
			'items_list_navigation'      => __( 'Book Categories list navigation', 'book-category' ),
			'items_list'                 => __( 'Book Categories list', 'book-category' ),
			'most_used'                  => _x( 'Most Used', 'book-category', 'book-category' ),
			'back_to_items'              => __( '&larr; Back to Book Categories', 'book-category' ),
		],
		'show_in_rest'          => true,
		'rest_base'             => 'book-category',
		'rest_controller_class' => 'WP_REST_Terms_Controller',
	] );

}

add_action( 'init', 'book_category_init' );

/**
 * Sets the post updated messages for the `book_category` taxonomy.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `book_category` taxonomy.
 */
function book_category_updated_messages( $messages ) {

	$messages['book-category'] = [
		0 => '', // Unused. Messages start at index 1.
		1 => __( 'Book Category added.', 'book-category' ),
		2 => __( 'Book Category deletedfalse.', 'book-category' ),
		3 => __( 'Book Category updated.', 'book-category' ),
		4 => __( 'Book Category not added.', 'book-category' ),
		5 => __( 'Book Category not updated.', 'book-category' ),
		6 => __( 'Book Categories deleted.', 'book-category' ),
	];

	return $messages;
}

add_filter( 'term_updated_messages', 'book_category_updated_messages' );
