<?php
/*
 * Plugin Name:       WP Book
 * Plugin URI:        https://rtcamp-learn.com/plugins/the-basics/
 * Description:       This Plugin Provide feature to Wp Book
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Naveen Dwivedi
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       my-basics-plugin
 * Domain Path:       /languages
 */

require_once __DIR__.'/post-types/book.php';
require_once __DIR__.'/taxonomies/book-category.php';
require_once __DIR__.'/taxonomies/book-tag.php';
require_once __DIR__.'/metaboxes/book-metaboxes.php';



 function wp_book_activation(){

 }
 register_activation_hook(
	__FILE__,
	'wp_book_activation'
);


function wp_book_deactivation(){

}
register_deactivation_hook(
	__FILE__,
	'wp_book_deactivation'
);

//**Book Settings
 
function add_books_settings_submenu() {
    // Add a submenu page under "Books" post type
    add_submenu_page(
        'edit.php?post_type=book',   // Parent menu (the custom post type "Books")
        'Book Settings',             // Page title
        'Settings',                  // Menu title
        'manage_options',            // Capability required to view this page
        'book-settings',             // Menu slug
        'books_settings_page_html'   // Callback function to render the settings page
    );
}
add_action('admin_menu', 'add_books_settings_submenu');

function books_settings_page_html() {
    // Check if the user is allowed to access this page
    if (!current_user_can('manage_options')) {
        return;
    }

    // Show settings updated message
    if (isset($_GET['settings-updated'])) {
        add_settings_error('book_settings_messages', 'book_settings_message', __('Settings Saved', 'textdomain'), 'updated');
    }

    // Show error/update messages
    settings_errors('book_settings_messages');
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form action="options.php" method="post">
            <?php
            // Output security fields for the registered setting "book_settings"
            settings_fields('book_settings');

            // Output setting sections and their fields
            do_settings_sections('book-settings');

            // Output the save settings button
            submit_button(__('Save Settings', 'textdomain'));
            ?>
        </form>
    </div>
    <?php
}


function books_settings_init() {
    // Register a new setting for "book_settings"
    register_setting('book_settings', 'book_settings_options');

    // Add a new section in the "book-settings" page
    add_settings_section(
        'book_settings_section',                // Section ID
        __('Book Display Settings', 'textdomain'), // Title of the section
        'books_settings_section_cb',            // Callback function to display the section description
        'book-settings'                         // Page to add the section to
    );

    // Add the "Currency" field to the section
    add_settings_field(
        'book_currency',                        // Field ID
        __('Currency', 'textdomain'),           // Field title
        'books_currency_field_cb',              // Callback function to display the field
        'book-settings',                        // Page on which to display the field
        'book_settings_section'                 // Section to display the field in
    );

    // Add the "Number of Books Per Page" field to the section
    add_settings_field(
        'book_per_page',                        // Field ID
        __('Number of Books per Page', 'textdomain'), // Field title
        'books_per_page_field_cb',              // Callback function to display the field
        'book-settings',                        // Page on which to display the field
        'book_settings_section'                 // Section to display the field in
    );
}
add_action('admin_init', 'books_settings_init');

// Callback for the settings section description
function books_settings_section_cb() {
    echo '<p>' . __('Configure how books are displayed, including currency and pagination settings.', 'textdomain') . '</p>';
}

// Callback for the currency field
function books_currency_field_cb() {
    $options = get_option('book_settings_options');
    $currency = isset($options['book_currency']) ? $options['book_currency'] : '$';
    ?>
    <input type="text" name="book_settings_options[book_currency]" value="<?php echo esc_attr($currency); ?>" size="5" />
    <p class="description"><?php _e('Enter the currency symbol, e.g., $, €, £.', 'textdomain'); ?></p>
    <?php
}

// Callback for the "Number of Books per Page" field
function books_per_page_field_cb() {
    $options = get_option('book_settings_options');
    $books_per_page = isset($options['book_per_page']) ? $options['book_per_page'] : 10;
    ?>
    <input type="number" name="book_settings_options[book_per_page]" value="<?php echo esc_attr($books_per_page); ?>" min="1" />
    <p class="description"><?php _e('Enter the number of books to display per page.', 'textdomain'); ?></p>
    <?php
}
//ShortCode

// Function to handle the [book] shortcode
function display_book_info( $atts ) {
    // Define default attributes
    $atts = shortcode_atts( array(
        'id'         => 'N/A',
        'author_name' => 'Unknown Author',
        'year'        => 'Unknown Year',
        'category'    => 'Uncategorized',
        'tag'         => 'No Tag',
        'publisher'   => 'Unknown Publisher',
    ), $atts, 'book' );
    
    // Create the HTML output for the book information
    $output = '<div class="book-info">';
    $output .= '<h3>Book ID: ' . esc_html( $atts['id'] ) . '</h3>';
    $output .= '<p><strong>Author:</strong> ' . esc_html( $atts['author_name'] ) . '</p>';
    $output .= '<p><strong>Year:</strong> ' . esc_html( $atts['year'] ) . '</p>';
    $output .= '<p><strong>Category:</strong> ' . esc_html( $atts['category'] ) . '</p>';
    $output .= '<p><strong>Tag:</strong> ' . esc_html( $atts['tag'] ) . '</p>';
    $output .= '<p><strong>Publisher:</strong> ' . esc_html( $atts['publisher'] ) . '</p>';
    $output .= '</div>';

    return $output;
}

// Register the shortcode
add_shortcode( 'book', 'display_book_info' );


// Register the custom book widget
function register_book_widget() {
    register_widget( 'Book_Widget' );
}
//add_action( 'widgets_init', 'register_book_widget' );
