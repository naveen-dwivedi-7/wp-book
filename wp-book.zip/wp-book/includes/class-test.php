<?php

class Test{



    public function display(){
        echo "class test file is running";
    }
}

