<?php

function add_book_meta_box() {
    add_meta_box(
        'book_meta_box',          // Unique ID for the meta box
        'Book Information',       // Title of the meta box
        'display_book_meta_box',  // Callback function that prints the meta box HTML
        'book',                   // Post type where the meta box should appear
        'side',                 // Context (normal, side, etc.)
        'high'                    // Priority (high, core, low, etc.)
    );
}
add_action('add_meta_boxes', 'add_book_meta_box');



function display_book_meta_box($post) {
    // Retrieve current values from the database, if any
    $author = get_post_meta($post->ID, 'book_author', true);
    $price = get_post_meta($post->ID, 'book_price', true);
    $publisher = get_post_meta($post->ID, 'book_publisher', true);
    $year = get_post_meta($post->ID, 'book_year', true);
    $edition = get_post_meta($post->ID, 'book_edition', true);
    $url = get_post_meta($post->ID, 'book_url', true);

    // Security nonce field
    wp_nonce_field('save_book_meta', 'book_meta_nonce');

    ?>
    <p>
        <label for="book_author">Author:</label>
        <input type="text" id="book_author" name="book_author" value="<?php echo esc_attr($author); ?>" size="25" />
    </p>
    <p>
        <label for="book_price">Price:</label>
        <input type="text" id="book_price" name="book_price" value="<?php echo esc_attr($price); ?>" size="10" />
    </p>
    <p>
        <label for="book_publisher">Publisher:</label>
        <input type="text" id="book_publisher" name="book_publisher" value="<?php echo esc_attr($publisher); ?>" size="25" />
    </p>
    <p>
        <label for="book_year">Year:</label>
        <input type="text" id="book_year" name="book_year" value="<?php echo esc_attr($year); ?>" size="4" />
    </p>
    <p>
        <label for="book_edition">Edition:</label>
        <input type="text" id="book_edition" name="book_edition" value="<?php echo esc_attr($edition); ?>" size="10" />
    </p>
    <p>
        <label for="book_url">URL:</label>
        <input type="url" id="book_url" name="book_url" value="<?php echo esc_attr($url); ?>" size="50" />
    </p>
    <?php
}





function save_book_meta($post_id) {
    // Check if nonce is set
    if (!isset($_POST['book_meta_nonce'])) {
        return;
    }

    // Verify the nonce to ensure this request came from the correct screen
    if (!wp_verify_nonce($_POST['book_meta_nonce'], 'save_book_meta')) {
        return;
    }

    // Check if the user has permission to save the post
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Check if this is an autosave; if so, don't save the data
    if (wp_is_post_autosave($post_id)) {
        return;
    }

    // Sanitize and save the form data
    if (isset($_POST['book_author'])) {
        update_post_meta($post_id, 'book_author', sanitize_text_field($_POST['book_author']));
    }
    if (isset($_POST['book_price'])) {
        update_post_meta($post_id, 'book_price', sanitize_text_field($_POST['book_price']));
    }
    if (isset($_POST['book_publisher'])) {
        update_post_meta($post_id, 'book_publisher', sanitize_text_field($_POST['book_publisher']));
    }
    if (isset($_POST['book_year'])) {
        update_post_meta($post_id, 'book_year', sanitize_text_field($_POST['book_year']));
    }
    if (isset($_POST['book_edition'])) {
        update_post_meta($post_id, 'book_edition', sanitize_text_field($_POST['book_edition']));
    }
    if (isset($_POST['book_url'])) {
        update_post_meta($post_id, 'book_url', esc_url_raw($_POST['book_url']));
    }
}
add_action('save_post', 'save_book_meta');

